// #ifndef checks if GRAPHICS_H hasn't yet been defined in any external file, and if not, will use the definition as defined here
// Here we use on the file itself. That way it can't be included multiple times.
#ifndef GRAPHICS_H 
#define GRAPHICS_H
#include <stdio.h> // Probably redundant
#include "game.h"

// Color definitions (8-bit format)
#define COLOR_BLACK    0x00
#define COLOR_WHITE    0xFF
#define COLOR_RED      0xE0
#define COLOR_GREEN    0x1C
#define COLOR_BLUE     0x03
#define COLOR_YELLOW   0xFC
#define COLOR_CYAN     0x1F
#define COLOR_MAGENTA  0xE3

#define VGA_WIDTH 320 // Horizontal screen size
#define VGA_HEIGHT 240 // Vertical screen size
#define PIXEL_SCALE 4

#define BACK_BUFFER 0x08012C00 // Not used

//  Main rendering function
void draw_frame(void);

// Helper drawing functions
void draw_block(volatile unsigned char *fb, int x, int y, int w, int h, unsigned char color);
void draw_line_h(volatile unsigned char *fb, int y, int x1, int x2, unsigned char color);
void draw_line_v(volatile unsigned char *fb, int x, int y1, int y2, unsigned char color);

void init_dma(void); // Not used
void swap_buffers(void); // Not used

#endif